<?php if (!defined( 'FW' )) die('Forbidden');

$options = array(
    'body-color' => array(
        'type' => 'color-picker',
        'label' => __('Цвет фона', '{domain}'),
        'value' => '#ADFF2F',
    ),


);
