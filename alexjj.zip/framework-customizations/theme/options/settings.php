<?php if (!defined( 'FW' )) die('Forbidden');

$options = array(

    'footer_text_email' => array(
        'type'  => 'textarea',
        'value' => 'default value',
        'attr'  => array( 'class' => 'custom-class', 'data-foo' => 'bar' ),
        'label' => __('Текст в футере', '{domain}'),
        'desc'  => __('Описание', '{domain}'),
        'help'  => __('Этот текст отображается в форме подписки', '{domain}'),
    ),





);
